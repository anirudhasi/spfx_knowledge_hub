# ============================================================
# CreateKHLists.ps1 - Knowledge Hub SharePoint List Setup
# Capgemini Technology Services
# Usage: .\CreateKHLists.ps1 -SiteUrl "https://capgemini.sharepoint.com/sites/InventKnowledgeHub"
# ============================================================
param([Parameter(Mandatory=$true)][string]$SiteUrl)

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Capgemini Knowledge Hub - List Setup" -ForegroundColor Cyan
Write-Host "  SPFx Complex Project v1.0" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

Connect-PnPOnline -Url $SiteUrl -Interactive

function Create-ListIfNotExists($name, $description) {
    $list = Get-PnPList -Identity $name -ErrorAction SilentlyContinue
    if ($list) { Write-Host "  ✓ List '$name' exists. Skipping." -ForegroundColor Green; return $false }
    New-PnPList -Title $name -Template GenericList -EnableVersioning -Description $description
    Write-Host "  ✓ Created list: $name" -ForegroundColor Green
    return $true
}

# ── 1. KH_Categories ─────────────────────────────────────────
Write-Host "`n[1/5] KH_Categories" -ForegroundColor Yellow
Create-ListIfNotExists "KH_Categories" "Article categories"
Add-PnPField -List "KH_Categories" -DisplayName "Description" -InternalName "Description" -Type Note -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Categories" -DisplayName "Icon" -InternalName "Icon" -Type Text -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Categories" -DisplayName "ParentCategory" -InternalName "ParentCategory" -Type Text -ErrorAction SilentlyContinue

$categories = @(
    @{Title="Technology";Description="Tech articles and tutorials";Icon="💻";ParentCategory=""},
    @{Title="Data Science";Description="ML, AI, Analytics";Icon="📊";ParentCategory=""},
    @{Title="Cloud & DevOps";Description="Azure, AWS, DevOps practices";Icon="☁️";ParentCategory=""},
    @{Title="Architecture";Description="Solution and enterprise architecture";Icon="🏗️";ParentCategory=""},
    @{Title="Agile & PM";Description="Project management and agile methods";Icon="📋";ParentCategory=""},
    @{Title="Leadership";Description="Leadership and soft skills";Icon="🎯";ParentCategory=""},
    @{Title="Security";Description="Cybersecurity and compliance";Icon="🔒";ParentCategory=""},
    @{Title="General";Description="General knowledge articles";Icon="📁";ParentCategory=""}
)
foreach ($c in $categories) {
    Add-PnPListItem -List "KH_Categories" -Values $c | Out-Null
    Write-Host "    Added: $($c.Title)" -ForegroundColor Gray
}

# ── 2. KH_Articles ───────────────────────────────────────────
Write-Host "`n[2/5] KH_Articles" -ForegroundColor Yellow
Create-ListIfNotExists "KH_Articles" "Knowledge base articles"
$articleFields = @(
    @{DisplayName="Summary";InternalName="Summary";Type="Note"},
    @{DisplayName="Content";InternalName="Content";Type="Note"},
    @{DisplayName="Category";InternalName="Category";Type="Text"},
    @{DisplayName="Tags";InternalName="Tags";Type="Text"},
    @{DisplayName="AuthorEmail";InternalName="AuthorEmail";Type="Text"},
    @{DisplayName="AuthorName";InternalName="AuthorName";Type="Text"},
    @{DisplayName="FeaturedImage";InternalName="FeaturedImage";Type="Text"},
    @{DisplayName="EstimatedReadMin";InternalName="EstimatedReadMin";Type="Number"}
)
foreach ($f in $articleFields) {
    Add-PnPField -List "KH_Articles" -DisplayName $f.DisplayName -InternalName $f.InternalName -Type $f.Type -AddToDefaultView -ErrorAction SilentlyContinue
}
Add-PnPField -List "KH_Articles" -DisplayName "Status" -InternalName "Status" -Type Choice -AddToDefaultView -ErrorAction SilentlyContinue
Set-PnPField -List "KH_Articles" -Identity "Status" -Values @{Choices=@("Draft","UnderReview","Published","Archived");DefaultValue="Draft"} -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Articles" -DisplayName "ViewCount" -InternalName "ViewCount" -Type Number -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Articles" -DisplayName "IsFeatured" -InternalName "IsFeatured" -Type Boolean -AddToDefaultView -ErrorAction SilentlyContinue

$articles = @(
    @{Title="Getting Started with SharePoint Framework (SPFx)";Summary="A complete beginner guide to SPFx development including setup, toolchain and your first web part.";Category="Technology";Tags="SPFx,SharePoint,React,TypeScript";AuthorEmail="chirag.jain@capgemini.com";AuthorName="Chirag Jain";Status="Published";ViewCount=245;IsFeatured=$true;EstimatedReadMin=12;Content="SharePoint Framework (SPFx) is the recommended development model for extending SharePoint Online. This guide walks through the complete setup process including Node.js installation, Yeoman generator, and building your first hello world web part."},
    @{Title="Microsoft Graph API Integration in SPFx";Summary="Learn how to integrate Microsoft Graph API into SPFx web parts to access user profiles, mail and calendar.";Category="Technology";Tags="Graph API,SPFx,Microsoft 365";AuthorEmail="chirag.jain@capgemini.com";AuthorName="Chirag Jain";Status="Published";ViewCount=189;IsFeatured=$true;EstimatedReadMin=15;Content="Microsoft Graph is the gateway to data and intelligence in Microsoft 365. In SPFx, you can use the MSGraphClientV3 to call Graph APIs. First, declare permissions in package-solution.json under webApiPermissionRequests. Then use context.msGraphClientFactory.getClient('3') to get the client."},
    @{Title="Power BI Embedded Analytics in SharePoint";Summary="Integrate Power BI reports directly into SharePoint pages for data-driven decision making.";Category="Data Science";Tags="Power BI,Analytics,SharePoint";AuthorEmail="arun.mehta@capgemini.com";AuthorName="Arun Mehta";Status="Published";ViewCount=156;IsFeatured=$false;EstimatedReadMin=10;Content="Power BI embedding in SharePoint allows teams to view live analytics without leaving the SharePoint environment. Use the Power BI embed URL from the Power BI service and configure it in a custom SPFx web part or use the native Power BI web part."},
    @{Title="Azure DevOps Pipelines Best Practices";Summary="Comprehensive guide to CI/CD pipeline setup, branching strategies and deployment automation.";Category="Cloud & DevOps";Tags="Azure DevOps,CI/CD,Pipelines";AuthorEmail="priya.sharma@capgemini.com";AuthorName="Priya Sharma";Status="Published";ViewCount=132;IsFeatured=$false;EstimatedReadMin=18;Content="Azure DevOps provides a complete DevOps solution from planning to deployment. Best practices include using YAML pipelines for infrastructure as code, implementing branch protection policies, using environment approvals for production deployments, and setting up automated testing gates."},
    @{Title="Introduction to Machine Learning with Python";Summary="Learn the fundamentals of machine learning using Python, Pandas, and Scikit-learn with real-world examples.";Category="Data Science";Tags="Machine Learning,Python,Scikit-learn,AI";AuthorEmail="ani@capgemini.com";AuthorName="Ani Kumar";Status="Published";ViewCount=298;IsFeatured=$true;EstimatedReadMin=20;Content="Machine learning enables systems to learn from data without explicit programming. This article covers supervised learning (classification, regression), unsupervised learning (clustering), and model evaluation techniques using Python's scikit-learn library."}
)
foreach ($a in $articles) {
    Add-PnPListItem -List "KH_Articles" -Values $a | Out-Null
    Write-Host "    Added: $($a.Title.Substring(0,[Math]::Min(50,$a.Title.Length)))..." -ForegroundColor Gray
}

# ── 3. KH_Ratings ────────────────────────────────────────────
Write-Host "`n[3/5] KH_Ratings" -ForegroundColor Yellow
Create-ListIfNotExists "KH_Ratings" "Article ratings and reviews"
Add-PnPField -List "KH_Ratings" -DisplayName "ArticleId" -InternalName "ArticleId" -Type Number -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Ratings" -DisplayName "UserId" -InternalName "UserId" -Type Text -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Ratings" -DisplayName "UserName" -InternalName "UserName" -Type Text -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Ratings" -DisplayName "Rating" -InternalName "Rating" -Type Number -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Ratings" -DisplayName "Comment" -InternalName "Comment" -Type Note -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Ratings" -DisplayName "HelpfulVotes" -InternalName "HelpfulVotes" -Type Number -ErrorAction SilentlyContinue

# ── 4. KH_LearningPaths ──────────────────────────────────────
Write-Host "`n[4/5] KH_LearningPaths" -ForegroundColor Yellow
Create-ListIfNotExists "KH_LearningPaths" "Learning path definitions"
Add-PnPField -List "KH_LearningPaths" -DisplayName "Description" -InternalName "Description" -Type Note -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_LearningPaths" -DisplayName "ArticleIds" -InternalName "ArticleIds" -Type Text -ErrorAction SilentlyContinue
Add-PnPField -List "KH_LearningPaths" -DisplayName "TargetRole" -InternalName "TargetRole" -Type Text -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_LearningPaths" -DisplayName "Level" -InternalName "Level" -Type Choice -AddToDefaultView -ErrorAction SilentlyContinue
Set-PnPField -List "KH_LearningPaths" -Identity "Level" -Values @{Choices=@("Beginner","Intermediate","Advanced");DefaultValue="Beginner"} -ErrorAction SilentlyContinue
Add-PnPField -List "KH_LearningPaths" -DisplayName "DurationHours" -InternalName "DurationHours" -Type Number -ErrorAction SilentlyContinue
Add-PnPField -List "KH_LearningPaths" -DisplayName "EnrollmentCount" -InternalName "EnrollmentCount" -Type Number -ErrorAction SilentlyContinue
Add-PnPField -List "KH_LearningPaths" -DisplayName "CompletionRate" -InternalName "CompletionRate" -Type Number -ErrorAction SilentlyContinue
Add-PnPField -List "KH_LearningPaths" -DisplayName "ThumbnailUrl" -InternalName "ThumbnailUrl" -Type Text -ErrorAction SilentlyContinue
Add-PnPField -List "KH_LearningPaths" -DisplayName "IsActive" -InternalName "IsActive" -Type Boolean -AddToDefaultView -ErrorAction SilentlyContinue

$paths = @(
    @{Title="SPFx Developer Bootcamp";Description="Complete learning path for SharePoint Framework development from zero to deployment.";ArticleIds="[1,2]";TargetRole="Developer";Level="Beginner";DurationHours=8;EnrollmentCount=42;CompletionRate=68;IsActive=$true},
    @{Title="Data Science with Python";Description="End-to-end data science learning track covering Python, ML, and visualization.";ArticleIds="[5]";TargetRole="Data Scientist";Level="Intermediate";DurationHours=16;EnrollmentCount=28;CompletionRate=45;IsActive=$true},
    @{Title="Azure Cloud Practitioner";Description="Azure fundamentals, DevOps and cloud architecture patterns for Capgemini projects.";ArticleIds="[4]";TargetRole="Cloud Engineer";Level="Intermediate";DurationHours=12;EnrollmentCount=35;CompletionRate=55;IsActive=$true}
)
foreach ($p in $paths) {
    Add-PnPListItem -List "KH_LearningPaths" -Values $p | Out-Null
    Write-Host "    Added: $($p.Title)" -ForegroundColor Gray
}

# ── 5. KH_Enrollments ────────────────────────────────────────
Write-Host "`n[5/5] KH_Enrollments" -ForegroundColor Yellow
Create-ListIfNotExists "KH_Enrollments" "User enrollment and progress tracking"
Add-PnPField -List "KH_Enrollments" -DisplayName "UserId" -InternalName "UserId" -Type Text -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "UserName" -InternalName "UserName" -Type Text -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "UserEmail" -InternalName "UserEmail" -Type Text -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "LearningPathId" -InternalName "LearningPathId" -Type Number -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "LearningPathTitle" -InternalName "LearningPathTitle" -Type Text -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "Progress" -InternalName "Progress" -Type Number -AddToDefaultView -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "Status" -InternalName "Status" -Type Choice -AddToDefaultView -ErrorAction SilentlyContinue
Set-PnPField -List "KH_Enrollments" -Identity "Status" -Values @{Choices=@("Enrolled","InProgress","Completed","Dropped");DefaultValue="Enrolled"} -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "EnrolledDate" -InternalName "EnrolledDate" -Type DateTime -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "CompletedDate" -InternalName "CompletedDate" -Type DateTime -ErrorAction SilentlyContinue
Add-PnPField -List "KH_Enrollments" -DisplayName "LastAccessedDate" -InternalName "LastAccessedDate" -Type DateTime -ErrorAction SilentlyContinue

# ── Create SharePoint Groups ──────────────────────────────────
Write-Host "`n[+] Creating SharePoint Groups" -ForegroundColor Yellow
New-PnPGroup -Title "KH_Admins" -Description "Knowledge Hub Administrators" -ErrorAction SilentlyContinue
New-PnPGroup -Title "KH_Authors" -Description "Knowledge Hub Content Authors" -ErrorAction SilentlyContinue
Write-Host "  Groups KH_Admins and KH_Authors created." -ForegroundColor Green

Write-Host "`n============================================" -ForegroundColor Green
Write-Host "  All 5 lists created successfully!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "1. Add yourself to KH_Admins group for full access" -ForegroundColor White
Write-Host "2. Approve Graph API permissions in SP Admin Center" -ForegroundColor White
Write-Host "3. Run: npm install && gulp serve" -ForegroundColor White
Write-Host "4. Add web part to workbench and test" -ForegroundColor White
Write-Host ""
Write-Host "Site: $SiteUrl" -ForegroundColor Cyan
