import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneSlider,
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import { spfi, SPFx } from '@pnp/sp';
import KnowledgeHub from './components/KnowledgeHub';
import { IKnowledgeHubProps } from './components/interfaces/IKnowledgeHubProps';

export interface IKnowledgeHubWebPartProps {
  title: string;
  adminGroupName: string;
  authorGroupName: string;
  flowWebhookUrl: string;
  featuredCount: number;
}

export default class KnowledgeHubWebPart extends BaseClientSideWebPart<IKnowledgeHubWebPartProps> {
  private _sp: ReturnType<typeof spfi>;

  protected async onInit(): Promise<void> {
    await super.onInit();
    this._sp = spfi().using(SPFx(this.context));
  }

  public render(): void {
    const element: React.ReactElement<IKnowledgeHubProps> = React.createElement(KnowledgeHub, {
      sp: this._sp,
      context: this.context,
      title: this.properties.title || 'Knowledge Hub & Learning Portal',
      adminGroupName: this.properties.adminGroupName || 'KH_Admins',
      authorGroupName: this.properties.authorGroupName || 'KH_Authors',
      flowWebhookUrl: this.properties.flowWebhookUrl || '',
      featuredCount: this.properties.featuredCount || 6,
      currentUserEmail: this.context.pageContext.user.email,
      currentUserName: this.context.pageContext.user.displayName,
      siteUrl: this.context.pageContext.web.absoluteUrl,
    });
    ReactDom.render(element, this.domElement);
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) return;
    const { semanticColors } = currentTheme;
    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
    }
  }

  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }
  protected get dataVersion(): Version { return Version.parse('1.0'); }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: { description: 'Configure Knowledge Hub Settings' },
        groups: [
          {
            groupName: 'General',
            groupFields: [
              PropertyPaneTextField('title', { label: 'Web Part Title' }),
              PropertyPaneSlider('featuredCount', { label: 'Featured Articles Count', min: 3, max: 12, step: 1, showValue: true }),
            ],
          },
          {
            groupName: 'Security Groups',
            groupFields: [
              PropertyPaneTextField('adminGroupName', { label: 'Admin Group Name', description: 'SharePoint group for admins' }),
              PropertyPaneTextField('authorGroupName', { label: 'Author Group Name', description: 'SharePoint group for authors' }),
            ],
          },
          {
            groupName: 'Power Automate',
            groupFields: [
              PropertyPaneTextField('flowWebhookUrl', { label: 'Flow Webhook URL', description: 'HTTP trigger URL for notifications', multiline: true, rows: 3 }),
            ],
          },
        ],
      }],
    };
  }
}
