import { SPFI } from '@pnp/sp';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import {
  TView, TRole, IArticle, ICategory, ILearningPath,
  IEnrollment, IUserProfile, IAnalyticsData, INewArticle
} from './IModels';

// ─── PROPS ────────────────────────────────────────────────────────────────────
export interface IKnowledgeHubProps {
  sp: SPFI;
  context: WebPartContext;
  title: string;
  adminGroupName: string;
  authorGroupName: string;
  flowWebhookUrl: string;
  featuredCount: number;
  currentUserEmail: string;
  currentUserName: string;
  siteUrl: string;
}

// ─── STATE ────────────────────────────────────────────────────────────────────
export interface IKnowledgeHubState {
  currentView: TView;
  selectedArticleId: number | null;
  currentUser: IUserProfile | null;
  userRole: TRole;
  isLoadingUser: boolean;
  articles: IArticle[];
  filteredArticles: IArticle[];
  categories: ICategory[];
  learningPaths: ILearningPath[];
  enrollments: IEnrollment[];
  analytics: IAnalyticsData | null;
  searchQuery: string;
  selectedCategory: string;
  selectedStatus: string;
  sortBy: 'newest' | 'popular' | 'rating';
  isLoading: boolean;
  errorMessage: string;
  successMessage: string;
  wizardStep: number;
  wizardData: Partial<INewArticle>;
  wizardErrors: Record<string, string>;
  isSubmittingWizard: boolean;
  adminSelectedTab: 'articles' | 'paths' | 'users';
}
