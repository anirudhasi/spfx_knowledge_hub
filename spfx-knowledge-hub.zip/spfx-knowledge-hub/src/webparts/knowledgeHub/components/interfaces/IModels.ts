export type TView = 'home' | 'articles' | 'article-detail' | 'learning-paths' | 'analytics' | 'admin' | 'wizard';
export type TRole = 'Employee' | 'Author' | 'Admin';
export type TArticleStatus = 'Draft' | 'Published' | 'Archived' | 'UnderReview';
export type TPathLevel = 'Beginner' | 'Intermediate' | 'Advanced';
export type TEnrollmentStatus = 'Enrolled' | 'InProgress' | 'Completed' | 'Dropped';

export interface IArticle {
  Id: number;
  Title: string;
  Summary: string;
  Content: string;
  Category: string;
  Tags: string;
  AuthorEmail: string;
  AuthorName: string;
  Status: TArticleStatus;
  ViewCount: number;
  FeaturedImage: string;
  IsFeatured: boolean;
  EstimatedReadMin: number;
  Created: string;
  Modified: string;
  AverageRating?: number;
  RatingCount?: number;
}

export interface INewArticle {
  Title: string;
  Summary: string;
  Content: string;
  Category: string;
  Tags: string;
  Status: TArticleStatus;
  FeaturedImage: string;
  IsFeatured: boolean;
  EstimatedReadMin: number;
}

export interface ICategory {
  Id: number;
  Title: string;
  Description: string;
  Icon: string;
  ParentCategory: string;
  ArticleCount?: number;
}

export interface IRating {
  Id: number;
  ArticleId: number;
  UserId: string;
  UserName: string;
  Rating: number;
  Comment: string;
  HelpfulVotes: number;
  Created: string;
}

export interface INewRating {
  ArticleId: number;
  UserId: string;
  UserName: string;
  Rating: number;
  Comment: string;
}

export interface ILearningPath {
  Id: number;
  Title: string;
  Description: string;
  ArticleIds: string;
  TargetRole: string;
  Level: TPathLevel;
  DurationHours: number;
  EnrollmentCount: number;
  CompletionRate: number;
  ThumbnailUrl: string;
  IsActive: boolean;
  Created: string;
  Articles?: IArticle[];
}

export interface IEnrollment {
  Id: number;
  UserId: string;
  UserName: string;
  UserEmail: string;
  LearningPathId: number;
  LearningPathTitle: string;
  Progress: number;
  Status: TEnrollmentStatus;
  EnrolledDate: string;
  CompletedDate: string;
  LastAccessedDate: string;
}

export interface IUserProfile {
  id: string;
  displayName: string;
  email: string;
  jobTitle: string;
  department: string;
  officeLocation: string;
  mobilePhone: string;
  photo: string;
  managerName: string;
  managerEmail: string;
}

export interface ICategoryStats {
  category: string;
  articleCount: number;
  totalViews: number;
  avgRating: number;
}

export interface IMonthlyStats {
  month: string;
  articlesCreated: number;
  totalViews: number;
  newEnrollments: number;
}

export interface IAnalyticsData {
  categoryStats: ICategoryStats[];
  monthlyStats: IMonthlyStats[];
  ratingDistribution: { rating: string; count: number }[];
  topArticles: IArticle[];
  totalArticles: number;
  totalViews: number;
  totalEnrollments: number;
  avgRating: number;
}

export interface IWizardStep {
  stepNumber: number;
  title: string;
  isValid: boolean;
}
