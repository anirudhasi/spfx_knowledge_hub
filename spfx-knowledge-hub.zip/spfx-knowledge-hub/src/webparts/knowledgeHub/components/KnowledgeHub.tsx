import * as React from 'react';
import { IKnowledgeHubProps, IKnowledgeHubState } from './interfaces/IKnowledgeHubProps';
import { SharePointService } from './services/SharePointService';
import { GraphService } from './services/GraphService';
import { ExcelExportService } from './services/ExcelExportService';
import { INewArticle } from './interfaces/IModels';
import styles from './KnowledgeHub.module.scss';
import HomeView from './views/HomeView';
import ArticlesView from './views/ArticlesView';
import ArticleDetailView from './views/ArticleDetailView';
import LearningPathsView from './views/LearningPathsView';
import AnalyticsView from './views/AnalyticsView';
import AdminView from './views/AdminView';
import ArticleWizard from './views/ArticleWizard';

export default class KnowledgeHub extends React.Component<IKnowledgeHubProps, IKnowledgeHubState> {
  private _spSvc: SharePointService;
  private _graphSvc: GraphService;

  constructor(props: IKnowledgeHubProps) {
    super(props);
    this._spSvc = new SharePointService(props.sp);
    this._graphSvc = new GraphService(props.context);
    this.state = {
      currentView: 'home', selectedArticleId: null, currentUser: null, userRole: 'Employee',
      isLoadingUser: true, articles: [], filteredArticles: [], categories: [],
      learningPaths: [], enrollments: [], analytics: null, searchQuery: '',
      selectedCategory: 'All', selectedStatus: 'All', sortBy: 'newest',
      isLoading: true, errorMessage: '', successMessage: '', wizardStep: 1,
      wizardData: { Status: 'Draft', Category: 'General', EstimatedReadMin: 5, IsFeatured: false },
      wizardErrors: {}, isSubmittingWizard: false, adminSelectedTab: 'articles',
    };
  }

  public async componentDidMount(): Promise<void> {
    await Promise.all([this._loadUserAndRole(), this._loadAllData()]);
  }

  private async _loadUserAndRole(): Promise<void> {
    try {
      const [user, role] = await Promise.all([
        this._graphSvc.getCurrentUserProfile(),
        this._spSvc.getUserRole(this.props.adminGroupName, this.props.authorGroupName),
      ]);
      this.setState({ currentUser: user, userRole: role, isLoadingUser: false });
    } catch { this.setState({ isLoadingUser: false }); }
  }

  private async _loadAllData(): Promise<void> {
    try {
      this.setState({ isLoading: true, errorMessage: '' });
      const [articles, categories, paths] = await Promise.all([
        this._spSvc.getArticles(),
        this._spSvc.getCategories(),
        this._spSvc.getLearningPaths(),
      ]);
      const enrichedCats = categories.map(c => ({
        ...c, ArticleCount: articles.filter(a => a.Category === c.Title && a.Status === 'Published').length,
      }));
      const enrollments = await this._spSvc.getEnrollmentsByUser(this.props.currentUserEmail);
      this.setState({
        articles, filteredArticles: articles.filter(a => a.Status === 'Published'),
        categories: enrichedCats, learningPaths: paths, enrollments, isLoading: false,
      });
    } catch (err) { this.setState({ isLoading: false, errorMessage: `Failed to load: ${err.message}` }); }
  }

  private _navigate(view: IKnowledgeHubState["currentView"], articleId?: number): void {
    this.setState({ currentView: view, selectedArticleId: articleId || null, successMessage: '' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  private _applyFilters(search: string, category: string, status: string, sort: string): void {
    let filtered = [...this.state.articles];
    if (status !== 'All') filtered = filtered.filter(a => a.Status === status);
    else filtered = filtered.filter(a => a.Status === 'Published');
    if (category !== 'All') filtered = filtered.filter(a => a.Category === category);
    if (search.trim()) {
      const q = search.toLowerCase();
      filtered = filtered.filter(a =>
        a.Title.toLowerCase().includes(q) || a.Summary.toLowerCase().includes(q) ||
        a.Tags.toLowerCase().includes(q) || a.AuthorName.toLowerCase().includes(q)
      );
    }
    if (sort === 'popular') filtered.sort((a, b) => b.ViewCount - a.ViewCount);
    else if (sort === 'rating') filtered.sort((a, b) => (b.AverageRating || 0) - (a.AverageRating || 0));
    else filtered.sort((a, b) => new Date(b.Created).getTime() - new Date(a.Created).getTime());
    this.setState({ filteredArticles: filtered, searchQuery: search, selectedCategory: category, sortBy: sort as any });
  }

  private async _openArticle(id: number): Promise<void> {
    this._navigate('article-detail', id);
    const article = this.state.articles.find(a => a.Id === id);
    if (article) await this._spSvc.incrementViewCount(id, article.ViewCount).catch(() => {});
  }

  private async _submitArticle(data: INewArticle): Promise<void> {
    this.setState({ isSubmittingWizard: true });
    try {
      const newId = await this._spSvc.createArticle(data, this.props.currentUserName, this.props.currentUserEmail);
      await this._spSvc.triggerFlow(this.props.flowWebhookUrl, {
        event: 'article_submitted', articleTitle: data.Title,
        authorName: this.props.currentUserName, authorEmail: this.props.currentUserEmail,
        status: data.Status, siteUrl: this.props.siteUrl, articleId: newId,
      });
      await this._loadAllData();
      this.setState({
        isSubmittingWizard: false, successMessage: `Article "${data.Title}" submitted!`,
        wizardData: { Status: 'Draft', Category: 'General', EstimatedReadMin: 5, IsFeatured: false }, wizardStep: 1,
      });
      this._navigate('articles');
    } catch (err) { this.setState({ isSubmittingWizard: false, errorMessage: `Submit failed: ${err.message}` }); }
  }

  private async _enrollInPath(pathId: number, pathTitle: string): Promise<void> {
    try {
      await this._spSvc.enrollInPath(this.props.currentUserEmail, this.props.currentUserName, this.props.currentUserEmail, pathId, pathTitle);
      const enrollments = await this._spSvc.getEnrollmentsByUser(this.props.currentUserEmail);
      this.setState({ enrollments, successMessage: `Enrolled in "${pathTitle}"!` });
    } catch (err) { this.setState({ errorMessage: `Enroll failed: ${err.message}` }); }
  }

  private async _loadAnalytics(): Promise<void> {
    if (this.state.analytics) return;
    try {
      const allEnrollments = await this._spSvc.getEnrollmentsByUser(this.props.currentUserEmail);
      const analytics = await this._spSvc.buildAnalytics(this.state.articles, allEnrollments);
      this.setState({ analytics });
    } catch (err) { this.setState({ errorMessage: `Analytics failed: ${err.message}` }); }
  }

  public render(): React.ReactElement {
    const {
      currentView, articles, filteredArticles, categories, learningPaths,
      enrollments, analytics, selectedArticleId, userRole, currentUser,
      searchQuery, selectedCategory, sortBy, isLoading, errorMessage,
      successMessage, wizardStep, wizardData, wizardErrors, isSubmittingWizard,
      adminSelectedTab, selectedStatus,
    } = this.state;

    const navItems = [
      { id: 'home',           label: '🏠 Home',           roles: ['Employee','Author','Admin'] },
      { id: 'articles',       label: '📚 Articles',       roles: ['Employee','Author','Admin'] },
      { id: 'learning-paths', label: '🎓 Learning Paths', roles: ['Employee','Author','Admin'] },
      { id: 'analytics',      label: '📊 Analytics',      roles: ['Author','Admin'] },
      { id: 'admin',          label: '⚙️ Admin',           roles: ['Admin'] },
    ];

    return (
      <div className={styles.root}>
        <div className={styles.header}>
          <div className={styles.headerLeft}>
            <span className={styles.logo}>💡</span>
            <div>
              <h1 className={styles.headerTitle}>{this.props.title}</h1>
              <p className={styles.headerSub}>Capgemini · InventKnowledgeHub</p>
            </div>
          </div>
          <div className={styles.headerRight}>
            {currentUser && (
              <div className={styles.userChip}>
                <div className={styles.userAvatar}>
                  {currentUser.photo
                    ? <img src={currentUser.photo} alt={currentUser.displayName} />
                    : <span>{(currentUser.displayName || "?").substring(0,2).toUpperCase()}</span>
                  }
                </div>
                <div className={styles.userInfo}>
                  <span className={styles.userName}>{currentUser.displayName}</span>
                  <span className={styles.userRole}>{userRole}</span>
                </div>
              </div>
            )}
            {(userRole === "Author" || userRole === "Admin") && (
              <button className={styles.writeBtn} onClick={() => this._navigate("wizard")}>✏️ Write Article</button>
            )}
          </div>
        </div>

        <nav className={styles.nav}>
          {navItems.filter(n => n.roles.includes(userRole)).map(n => (
            <button key={n.id}
              className={`${styles.navBtn} ${currentView === n.id ? styles.navActive : ""}`}
              onClick={() => { this._navigate(n.id as any); if (n.id === "analytics") this._loadAnalytics(); }}>
              {n.label}
            </button>
          ))}
        </nav>

        {successMessage && (
          <div className={styles.successBanner}>✅ {successMessage}
            <button className={styles.bannerClose} onClick={() => this.setState({ successMessage: "" })}>✕</button>
          </div>
        )}
        {errorMessage && (
          <div className={styles.errorBanner}>⚠️ {errorMessage}
            <button className={styles.bannerClose} onClick={() => this.setState({ errorMessage: "" })}>✕</button>
          </div>
        )}

        <div className={styles.content}>
          {isLoading ? (
            <div className={styles.loadingScreen}><div className={styles.loadSpinner} /><p>Loading Knowledge Hub...</p></div>
          ) : (
            <>
              {currentView === "home" && (
                <HomeView articles={articles.filter(a => a.Status === "Published")} categories={categories}
                  featuredCount={this.props.featuredCount} onOpenArticle={(id) => this._openArticle(id)}
                  onNavigate={(view) => this._navigate(view as any)} />
              )}
              {currentView === "articles" && (
                <ArticlesView articles={filteredArticles} categories={categories} userRole={userRole}
                  searchQuery={searchQuery} selectedCategory={selectedCategory} selectedStatus={selectedStatus}
                  sortBy={sortBy} onOpenArticle={(id) => this._openArticle(id)}
                  onFilterChange={(s, c, st, sort) => this._applyFilters(s, c, st, sort)}
                  onExport={() => ExcelExportService.exportArticles(filteredArticles)} />
              )}
              {currentView === "article-detail" && selectedArticleId && (
                <ArticleDetailView articleId={selectedArticleId} articles={articles} userRole={userRole}
                  currentUserEmail={this.props.currentUserEmail} currentUserName={this.props.currentUserName}
                  spSvc={this._spSvc} onBack={() => this._navigate("articles")}
                  onDelete={async (id) => { await this._spSvc.deleteArticle(id); await this._loadAllData(); this._navigate("articles"); }} />
              )}
              {currentView === "learning-paths" && (
                <LearningPathsView paths={learningPaths} enrollments={enrollments} articles={articles}
                  currentUserId={this.props.currentUserEmail} userRole={userRole}
                  onEnroll={(id, title) => this._enrollInPath(id, title)}
                  onUpdateProgress={async (enrollId, prog) => {
                    await this._spSvc.updateProgress(enrollId, prog);
                    const updated = await this._spSvc.getEnrollmentsByUser(this.props.currentUserEmail);
                    this.setState({ enrollments: updated });
                  }}
                  onExport={() => ExcelExportService.exportEnrollments(enrollments)} />
              )}
              {currentView === "analytics" && (
                <AnalyticsView analytics={analytics}
                  onExportArticles={() => ExcelExportService.exportArticles(articles)}
                  onExportPaths={() => ExcelExportService.exportLearningPaths(learningPaths)} />
              )}
              {currentView === "admin" && userRole === "Admin" && (
                <AdminView articles={articles} paths={learningPaths} categories={categories}
                  selectedTab={adminSelectedTab} spSvc={this._spSvc}
                  onTabChange={(tab) => this.setState({ adminSelectedTab: tab })}
                  onRefresh={() => this._loadAllData()}
                  onDeleteArticle={async (id) => { await this._spSvc.deleteArticle(id); await this._loadAllData(); }}
                  onUpdateStatus={async (id, status) => { await this._spSvc.updateArticle(id, { Status: status }); await this._loadAllData(); this.setState({ successMessage: `Status updated to ${status}` }); }}
                  onExportArticles={() => ExcelExportService.exportArticles(articles)} />
              )}
              {currentView === "wizard" && (
                <ArticleWizard categories={categories} step={wizardStep} data={wizardData}
                  errors={wizardErrors} isSubmitting={isSubmittingWizard} userRole={userRole}
                  onStepChange={(s) => this.setState({ wizardStep: s })}
                  onDataChange={(field, value) => this.setState(prev => ({ wizardData: { ...prev.wizardData, [field]: value } }))}
                  onSubmit={(data) => this._submitArticle(data as INewArticle)}
                  onCancel={() => this._navigate("articles")} />
              )}
            </>
          )}
        </div>
        <div className={styles.footer}>
          <span>Knowledge Hub v1.0 · Capgemini Technology Services · SPFx 1.20 + Node 22 + HEFT</span>
          <span>Built by: {this.props.currentUserName}</span>
        </div>
      </div>
    );
  }
}
