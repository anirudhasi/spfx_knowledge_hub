import * as React from 'react';
import { IArticle, IRating, TRole } from '../interfaces/IModels';
import { SharePointService } from '../services/SharePointService';
import styles from './ArticleDetailView.module.scss';

interface IProps {
  articleId: number;
  articles: IArticle[];
  userRole: TRole;
  currentUserEmail: string;
  currentUserName: string;
  spSvc: SharePointService;
  onBack: () => void;
  onDelete: (id: number) => void;
}

interface IState {
  ratings: IRating[];
  myRating: number;
  myComment: string;
  isSubmittingRating: boolean;
  ratingSuccess: boolean;
}

export default class ArticleDetailView extends React.Component<IProps, IState> {
  constructor(props: IProps) {
    super(props);
    this.state = { ratings: [], myRating: 0, myComment: '', isSubmittingRating: false, ratingSuccess: false };
  }
  public async componentDidMount(): Promise<void> {
    await this._loadRatings();
  }
  private async _loadRatings(): Promise<void> {
    const ratings = await this.props.spSvc.getRatingsByArticle(this.props.articleId);
    const mine = ratings.find(r => r.UserId === this.props.currentUserEmail);
    this.setState({ ratings, myRating: mine?.Rating || 0, myComment: mine?.Comment || '' });
  }
  private async _submitRating(): Promise<void> {
    if (!this.state.myRating) return;
    this.setState({ isSubmittingRating: true });
    await this.props.spSvc.submitRating({
      ArticleId: this.props.articleId, UserId: this.props.currentUserEmail,
      UserName: this.props.currentUserName, Rating: this.state.myRating, Comment: this.state.myComment,
    });
    await this._loadRatings();
    this.setState({ isSubmittingRating: false, ratingSuccess: true });
    setTimeout(() => this.setState({ ratingSuccess: false }), 3000);
  }
  public render(): React.ReactElement {
    const article = this.props.articles.find(a => a.Id === this.props.articleId);
    if (!article) return <div className={styles.notFound}><p>Article not found.</p><button className="kh-btn-secondary" onClick={this.props.onBack}>← Back</button></div>;
    const { ratings, myRating, myComment, isSubmittingRating, ratingSuccess } = this.state;
    const avgRating = ratings.length ? ratings.reduce((s,r) => s+r.Rating, 0) / ratings.length : 0;
    const statusColors: Record<string,{bg:string,color:string}> = {
      'Published':{bg:'#dff6dd',color:'#107c10'}, 'Draft':{bg:'#fff4ce',color:'#7a4100'},
      'Archived':{bg:'#f3f2f1',color:'#605e5c'}, 'UnderReview':{bg:'#deecf9',color:'#0078d4'},
    };
    const sc = statusColors[article.Status] || statusColors['Draft'];
    return (
      <div className={styles.detail}>
        <div className={styles.toolbar}>
          <button className="kh-btn-secondary" onClick={this.props.onBack}>← Back to Articles</button>
          {(this.props.userRole === 'Admin') && (
            <button className="kh-btn-danger" onClick={() => { if(window.confirm('Delete this article?')) this.props.onDelete(article.Id); }}>🗑 Delete</button>
          )}
        </div>
        <div className={styles.articleHeader}>
          <div className={styles.badges}>
            <span className="kh-badge" style={{background:sc.bg,color:sc.color}}>{article.Status}</span>
            <span className="kh-badge" style={{background:'#f3f2f1',color:'#323130'}}>{article.Category}</span>
            {article.IsFeatured && <span className="kh-badge" style={{background:'#fff4ce',color:'#7a4100'}}>⭐ Featured</span>}
          </div>
          <h2 className={styles.articleTitle}>{article.Title}</h2>
          <p className={styles.articleSummary}>{article.Summary}</p>
          <div className={styles.articleMeta}>
            <span>👤 {article.AuthorName}</span>
            <span>⏱ {article.EstimatedReadMin} min read</span>
            <span>👁 {article.ViewCount} views</span>
            <span>📅 {new Date(article.Created).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'})}</span>
            <span>
              {[1,2,3,4,5].map(s => <span key={s} className={s <= Math.round(avgRating) ? 'kh-star-filled' : 'kh-star-empty'}>★</span>)}
              <span style={{fontSize:'12px',color:'#888',marginLeft:'4px'}}>{avgRating.toFixed(1)} ({ratings.length} reviews)</span>
            </span>
          </div>
          {article.Tags && (
            <div className={styles.tags}>
              {article.Tags.split(',').map((t,i) => <span key={i} className={styles.tag}>{t.trim()}</span>)}
            </div>
          )}
        </div>
        <div className={styles.articleBody}>
          {article.Content.split('\n').map((p, i) => p.trim() ? <p key={i}>{p}</p> : <br key={i}/>)}
        </div>
        {/* Rating Section */}
        <div className={styles.ratingSection}>
          <h3 className={styles.ratingTitle}>⭐ Rate This Article</h3>
          {ratingSuccess && <div className={styles.ratingSuccess}>✅ Thank you for your rating!</div>}
          <div className={styles.starPicker}>
            {[1,2,3,4,5].map(s => (
              <button key={s} className={`${styles.starBtn} ${s <= myRating ? styles.starActive : ''}`}
                onClick={() => this.setState({ myRating: s })}>★</button>
            ))}
            <span className={styles.ratingLabel}>{myRating > 0 ? ['','Poor','Fair','Good','Very Good','Excellent'][myRating] : 'Click to rate'}</span>
          </div>
          <textarea className="kh-input" rows={3} placeholder="Share your thoughts (optional)..."
            value={myComment} onChange={e => this.setState({ myComment: e.target.value })}
            style={{marginTop:'10px',resize:'vertical'}} />
          <button className="kh-btn-primary" style={{marginTop:'10px'}}
            onClick={() => this._submitRating()} disabled={!myRating || isSubmittingRating}>
            {isSubmittingRating ? '⏳ Submitting...' : '✓ Submit Rating'}
          </button>
        </div>
        {/* Reviews */}
        {ratings.length > 0 && (
          <div className={styles.reviews}>
            <h3 className={styles.reviewsTitle}>💬 Reviews ({ratings.length})</h3>
            {ratings.map(r => (
              <div key={r.Id} className={styles.review}>
                <div className={styles.reviewHeader}>
                  <div className={styles.reviewAvatar}>{r.UserName.substring(0,2).toUpperCase()}</div>
                  <div>
                    <span className={styles.reviewUser}>{r.UserName}</span>
                    <div>{[1,2,3,4,5].map(s => <span key={s} className={s <= r.Rating ? 'kh-star-filled' : 'kh-star-empty'} style={{fontSize:'13px'}}>★</span>)}</div>
                  </div>
                  <span className={styles.reviewDate}>{new Date(r.Created).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'})}</span>
                </div>
                {r.Comment && <p className={styles.reviewComment}>{r.Comment}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }
}