import * as React from 'react';
import { ICategory, INewArticle, TRole } from '../interfaces/IModels';
import styles from './ArticleWizard.module.scss';

interface IProps {
  categories: ICategory[];
  step: number;
  data: Partial<INewArticle>;
  errors: Record<string,string>;
  isSubmitting: boolean;
  userRole: TRole;
  onStepChange: (step: number) => void;
  onDataChange: (field: string, value: any) => void;
  onSubmit: (data: Partial<INewArticle>) => void;
  onCancel: () => void;
}

const STEPS = [
  { num:1, title:'Basic Info', icon:'📝', desc:'Title, category and summary' },
  { num:2, title:'Content',   icon:'✍️', desc:'Article body and tags' },
  { num:3, title:'Review',    icon:'👁', desc:'Preview and publish' },
];

const ArticleWizard: React.FunctionComponent<IProps> = (props) => {
  const { categories, step, data, errors, isSubmitting, userRole, onStepChange, onDataChange, onSubmit, onCancel } = props;

  const validateStep1 = (): boolean => {
    return !!(data.Title?.trim() && data.Category && data.Summary?.trim());
  };
  const validateStep2 = (): boolean => {
    return !!(data.Content?.trim() && data.Content.length > 50);
  };

  const canProceed = step === 1 ? validateStep1() : step === 2 ? validateStep2() : true;

  return (
    <div className={styles.wizard}>
      {/* Wizard Header */}
      <div className={styles.wizardHeader}>
        <h3 className={styles.wizardTitle}>✏️ Submit New Article</h3>
        <p className={styles.wizardSub}>Share your knowledge with the Capgemini community</p>
      </div>

      {/* Step Indicators */}
      <div className={styles.stepIndicators}>
        {STEPS.map(s => (
          <div key={s.num} className={`${styles.stepIndicator} ${step===s.num?styles.stepActive:''} ${step>s.num?styles.stepDone:''}`}>
            <div className={styles.stepCircle}>
              {step > s.num ? '✓' : s.icon}
            </div>
            <div className={styles.stepInfo}>
              <span className={styles.stepTitle}>{s.title}</span>
              <span className={styles.stepDesc}>{s.desc}</span>
            </div>
            {s.num < STEPS.length && <div className={styles.stepLine} />}
          </div>
        ))}
      </div>

      {/* Step 1: Basic Info */}
      {step === 1 && (
        <div className={styles.stepContent}>
          <div className={styles.formGroup}>
            <label className={styles.label}>Article Title <span className={styles.req}>*</span></label>
            <input className="kh-input" placeholder="e.g. How to Build Scalable React Applications"
              value={data.Title||''} onChange={e => onDataChange('Title', e.target.value)} maxLength={200}/>
            <span className={styles.hint}>{(data.Title||'').length}/200 characters</span>
            {errors.Title && <span className={styles.error}>{errors.Title}</span>}
          </div>
          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <label className={styles.label}>Category <span className={styles.req}>*</span></label>
              <select className="kh-select" style={{width:'100%'}} value={data.Category||''}
                onChange={e => onDataChange('Category', e.target.value)}>
                <option value="">Select a category</option>
                {categories.map(c => <option key={c.Id} value={c.Title}>{c.Icon} {c.Title}</option>)}
              </select>
            </div>
            <div className={styles.formGroup}>
              <label className={styles.label}>Estimated Read Time (minutes)</label>
              <input className="kh-input" type="number" min={1} max={120}
                value={data.EstimatedReadMin||5} onChange={e => onDataChange('EstimatedReadMin', parseInt(e.target.value)||5)}/>
            </div>
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label}>Summary <span className={styles.req}>*</span></label>
            <textarea className="kh-input" rows={3} placeholder="Brief description of what this article covers..."
              value={data.Summary||''} onChange={e => onDataChange('Summary', e.target.value)} maxLength={500}
              style={{resize:'vertical'}}/>
            <span className={styles.hint}>{(data.Summary||'').length}/500 characters</span>
          </div>
          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <label className={styles.label}>Featured Image URL</label>
              <input className="kh-input" placeholder="https://..." value={data.FeaturedImage||''}
                onChange={e => onDataChange('FeaturedImage', e.target.value)}/>
            </div>
          </div>
          {userRole === 'Admin' && (
            <div className={styles.formGroup}>
              <label className={styles.checkLabel}>
                <input type="checkbox" checked={!!data.IsFeatured}
                  onChange={e => onDataChange('IsFeatured', e.target.checked)}/>
                <span>⭐ Mark as Featured Article</span>
              </label>
            </div>
          )}
        </div>
      )}

      {/* Step 2: Content */}
      {step === 2 && (
        <div className={styles.stepContent}>
          <div className={styles.formGroup}>
            <label className={styles.label}>Article Content <span className={styles.req}>*</span></label>
            <textarea className="kh-input" rows={18}
              placeholder="Write your article content here. Use line breaks to separate paragraphs.&#10;&#10;Example:&#10;## Introduction&#10;This article explains...&#10;&#10;## Key Concepts&#10;..."
              value={data.Content||''} onChange={e => onDataChange('Content', e.target.value)}
              style={{resize:'vertical',fontFamily:'monospace',fontSize:'13px',lineHeight:'1.6'}}/>
            <span className={styles.hint}>{(data.Content||'').length} characters · {(data.Content||'').split(' ').filter(Boolean).length} words</span>
            {errors.Content && <span className={styles.error}>{errors.Content}</span>}
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label}>Tags (comma-separated)</label>
            <input className="kh-input" placeholder="e.g. React, TypeScript, SharePoint, SPFx"
              value={data.Tags||''} onChange={e => onDataChange('Tags', e.target.value)}/>
            {data.Tags && (
              <div className={styles.tagPreview}>
                {data.Tags.split(',').filter(t=>t.trim()).map((t,i) => (
                  <span key={i} className={styles.tagChip}>{t.trim()}</span>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Step 3: Review */}
      {step === 3 && (
        <div className={styles.stepContent}>
          <div className={styles.preview}>
            <div className={styles.previewBadges}>
              <span className="kh-badge" style={{background:'#f3f2f1',color:'#323130'}}>{data.Category}</span>
              {data.IsFeatured && <span className="kh-badge" style={{background:'#fff4ce',color:'#7a4100'}}>⭐ Featured</span>}
            </div>
            <h2 className={styles.previewTitle}>{data.Title}</h2>
            <p className={styles.previewSummary}>{data.Summary}</p>
            <div className={styles.previewMeta}>
              <span>⏱ {data.EstimatedReadMin} min read</span>
              {data.Tags && <span>🏷 {data.Tags}</span>}
            </div>
            <div className={styles.previewBody}>
              {(data.Content||'').substring(0,400)}{(data.Content||'').length > 400 ? '...' : ''}
            </div>
          </div>
          <div className={styles.formGroup} style={{marginTop:'16px'}}>
            <label className={styles.label}>Publishing Status</label>
            <select className="kh-select" style={{width:'100%'}} value={data.Status||'Draft'}
              onChange={e => onDataChange('Status', e.target.value)}>
              <option value="Draft">📝 Save as Draft</option>
              {(userRole === 'Author' || userRole === 'Admin') && <option value="UnderReview">🔍 Submit for Review</option>}
              {userRole === 'Admin' && <option value="Published">✅ Publish Now</option>}
            </select>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className={styles.wizardFooter}>
        <button className="kh-btn-secondary" onClick={onCancel} disabled={isSubmitting}>Cancel</button>
        <div className={styles.navBtns}>
          {step > 1 && (
            <button className="kh-btn-secondary" onClick={() => onStepChange(step-1)} disabled={isSubmitting}>← Previous</button>
          )}
          {step < 3 && (
            <button className="kh-btn-primary" onClick={() => onStepChange(step+1)} disabled={!canProceed}>Next →</button>
          )}
          {step === 3 && (
            <button className="kh-btn-primary" onClick={() => onSubmit(data)} disabled={isSubmitting || !canProceed}>
              {isSubmitting ? '⏳ Submitting...' : `✓ ${data.Status === 'Published' ? 'Publish' : data.Status === 'UnderReview' ? 'Submit for Review' : 'Save Draft'}`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
export default ArticleWizard;