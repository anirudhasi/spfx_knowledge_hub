import * as React from 'react';
import { IArticle, ICategory } from '../interfaces/IModels';
import styles from './HomeView.module.scss';

interface IHomeViewProps {
  articles: IArticle[];
  categories: ICategory[];
  featuredCount: number;
  onOpenArticle: (id: number) => void;
  onNavigate: (view: string) => void;
}

function StarRating({ rating }: { rating: number }): React.ReactElement {
  return (
    <span>
      {[1,2,3,4,5].map(s => (
        <span key={s} className={s <= Math.round(rating) ? 'kh-star-filled' : 'kh-star-empty'}>★</span>
      ))}
      <span style={{fontSize:'11px',color:'#888',marginLeft:'4px'}}>{rating.toFixed(1)}</span>
    </span>
  );
}

const HomeView: React.FunctionComponent<IHomeViewProps> = ({ articles, categories, featuredCount, onOpenArticle, onNavigate }) => {
  const featured = articles.filter(a => a.IsFeatured).slice(0, featuredCount);
  const recent = articles.sort((a,b) => new Date(b.Created).getTime() - new Date(a.Created).getTime()).slice(0, 6);
  const topRated = [...articles].sort((a,b) => (b.AverageRating||0) - (a.AverageRating||0)).slice(0,4);

  const tagColors: Record<string,string> = {
    'Published':'#107c10','Draft':'#7a4100','Archived':'#605e5c','UnderReview':'#0078d4'
  };
  const levelColors: Record<string,string> = {
    'Beginner':'#107c10','Intermediate':'#7a4100','Advanced':'#a4262c'
  };

  return (
    <div className={styles.home}>
      {/* Hero */}
      <div className={styles.hero}>
        <h2 className={styles.heroTitle}>Welcome to Capgemini Knowledge Hub 💡</h2>
        <p className={styles.heroSub}>Discover articles, learning paths, and insights from across Capgemini Technology Services.</p>
        <div className={styles.heroStats}>
          <div className={styles.heroStat}><span className={styles.heroStatVal}>{articles.length}</span><span className={styles.heroStatLbl}>Articles</span></div>
          <div className={styles.heroStat}><span className={styles.heroStatVal}>{categories.length}</span><span className={styles.heroStatLbl}>Categories</span></div>
          <div className={styles.heroStat}><span className={styles.heroStatVal}>{articles.reduce((s,a)=>s+a.ViewCount,0).toLocaleString()}</span><span className={styles.heroStatLbl}>Total Views</span></div>
          <div className={styles.heroStat}><span className={styles.heroStatVal}>{articles.filter(a=>a.IsFeatured).length}</span><span className={styles.heroStatLbl}>Featured</span></div>
        </div>
      </div>

      {/* Categories */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <h3 className={styles.sectionTitle}>📁 Browse by Category</h3>
          <button className="kh-btn-secondary" onClick={() => onNavigate('articles')}>View All →</button>
        </div>
        <div className={styles.catGrid}>
          {categories.map(c => (
            <div key={c.Id} className={styles.catCard} onClick={() => onNavigate('articles')}>
              <span className={styles.catIcon}>{c.Icon}</span>
              <span className={styles.catName}>{c.Title}</span>
              <span className={styles.catCount}>{c.ArticleCount || 0} articles</span>
            </div>
          ))}
        </div>
      </div>

      {/* Featured */}
      {featured.length > 0 && (
        <div className={styles.section}>
          <div className={styles.sectionHeader}>
            <h3 className={styles.sectionTitle}>⭐ Featured Articles</h3>
          </div>
          <div className={styles.featuredGrid}>
            {featured.map(a => (
              <div key={a.Id} className="kh-card" onClick={() => onOpenArticle(a.Id)}>
                <div className={styles.cardMeta}>
                  <span className="kh-badge" style={{background:'#fff4ce',color:'#7a4100'}}>⭐ Featured</span>
                  <span style={{fontSize:'11px',color:'#888'}}>{a.EstimatedReadMin} min read</span>
                </div>
                <h4 className={styles.cardTitle}>{a.Title}</h4>
                <p className={styles.cardSummary}>{a.Summary.length > 100 ? a.Summary.substring(0,100)+'...' : a.Summary}</p>
                <div className={styles.cardFooter}>
                  <span className={styles.cardAuthor}>👤 {a.AuthorName}</span>
                  <StarRating rating={a.AverageRating||0} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <h3 className={styles.sectionTitle}>🕒 Recently Added</h3>
          <button className="kh-btn-secondary" onClick={() => onNavigate('articles')}>All Articles →</button>
        </div>
        <div className={styles.recentGrid}>
          {recent.map(a => (
            <div key={a.Id} className={`kh-card ${styles.recentCard}`} onClick={() => onOpenArticle(a.Id)}>
              <div className={styles.cardMeta}>
                <span className="kh-badge" style={{background:'#f3f2f1',color:'#323130'}}>{a.Category}</span>
                <span style={{fontSize:'11px',color:'#888'}}>{new Date(a.Created).toLocaleDateString('en-GB',{day:'2-digit',month:'short'})}</span>
              </div>
              <h4 className={styles.cardTitle}>{a.Title}</h4>
              <div className={styles.cardFooter}>
                <span style={{fontSize:'11px',color:'#888'}}>👁 {a.ViewCount} views</span>
                <StarRating rating={a.AverageRating||0} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top Rated */}
      {topRated.length > 0 && (
        <div className={styles.section}>
          <h3 className={styles.sectionTitle}>🏆 Top Rated</h3>
          <div className={styles.topRatedList}>
            {topRated.map((a,i) => (
              <div key={a.Id} className={styles.topRatedItem} onClick={() => onOpenArticle(a.Id)}>
                <span className={styles.rank}>#{i+1}</span>
                <div className={styles.topRatedInfo}>
                  <span className={styles.topRatedTitle}>{a.Title}</span>
                  <span className={styles.topRatedMeta}>{a.Category} · 👁 {a.ViewCount}</span>
                </div>
                <StarRating rating={a.AverageRating||0} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default HomeView;