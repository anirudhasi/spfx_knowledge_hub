import * as React from 'react';
import { IArticle, ILearningPath, ICategory, TArticleStatus } from '../interfaces/IModels';
import { SharePointService } from '../services/SharePointService';
import styles from './AdminView.module.scss';

interface IProps {
  articles: IArticle[];
  paths: ILearningPath[];
  categories: ICategory[];
  selectedTab: 'articles'|'paths'|'users';
  spSvc: SharePointService;
  onTabChange: (tab:'articles'|'paths'|'users') => void;
  onRefresh: () => void;
  onDeleteArticle: (id: number) => void;
  onUpdateStatus: (id: number, status: TArticleStatus) => void;
  onExportArticles: () => void;
}

const STATUS_COLORS: Record<string,{bg:string,color:string}> = {
  'Published':{bg:'#dff6dd',color:'#107c10'},
  'Draft':{bg:'#fff4ce',color:'#7a4100'},
  'UnderReview':{bg:'#deecf9',color:'#0078d4'},
  'Archived':{bg:'#f3f2f1',color:'#605e5c'},
};

const AdminView: React.FunctionComponent<IProps> = (props) => {
  const { articles, paths, categories, selectedTab, onTabChange, onRefresh, onDeleteArticle, onUpdateStatus, onExportArticles } = props;

  const tabs = [
    { id:'articles', label:`📚 Articles (${articles.length})` },
    { id:'paths', label:`🎓 Learning Paths (${paths.length})` },
    { id:'users', label:'⚙️ Settings' },
  ];

  return (
    <div className={styles.adminView}>
      <div className={styles.adminHeader}>
        <h3 className={styles.adminTitle}>⚙️ Admin Panel</h3>
        <div className={styles.adminActions}>
          <button className="kh-btn-secondary" onClick={onRefresh}>↻ Refresh</button>
          <button className="kh-btn-secondary" onClick={onExportArticles}>📥 Export All</button>
        </div>
      </div>

      <div className={styles.tabs}>
        {tabs.map(t => (
          <button key={t.id} className={`${styles.tab} ${selectedTab===t.id?styles.tabActive:''}`}
            onClick={() => onTabChange(t.id as any)}>{t.label}</button>
        ))}
      </div>

      {selectedTab === 'articles' && (
        <div className={styles.tableWrapper}>
          <table className={styles.adminTable}>
            <thead>
              <tr><th>ID</th><th>Title</th><th>Category</th><th>Author</th><th>Status</th><th>Views</th><th>Rating</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {articles.map(a => {
                const sc = STATUS_COLORS[a.Status]||STATUS_COLORS['Draft'];
                return (
                  <tr key={a.Id}>
                    <td style={{color:'#888',fontWeight:600}}>#{a.Id}</td>
                    <td style={{fontWeight:500,maxWidth:'180px'}}>{a.Title}</td>
                    <td><span className="kh-badge" style={{background:'#f3f2f1',color:'#323130'}}>{a.Category}</span></td>
                    <td style={{fontSize:'12px'}}>{a.AuthorName}</td>
                    <td>
                      <select className={styles.statusSelect} value={a.Status}
                        style={{color:sc.color,background:sc.bg,border:`1px solid ${sc.color}`,padding:'3px 6px',borderRadius:'2px',fontSize:'11px',fontWeight:600,cursor:'pointer'}}
                        onChange={e => onUpdateStatus(a.Id, e.target.value as TArticleStatus)}>
                        <option value="Draft">Draft</option>
                        <option value="UnderReview">Under Review</option>
                        <option value="Published">Published</option>
                        <option value="Archived">Archived</option>
                      </select>
                    </td>
                    <td>{a.ViewCount}</td>
                    <td>{(a.AverageRating||0).toFixed(1)}★ ({a.RatingCount||0})</td>
                    <td>
                      <button className="kh-btn-danger" style={{fontSize:'11px',padding:'4px 10px'}}
                        onClick={() => { if(window.confirm(`Delete "${a.Title}"?`)) onDeleteArticle(a.Id); }}>
                        🗑 Delete
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {selectedTab === 'paths' && (
        <div className={styles.tableWrapper}>
          <table className={styles.adminTable}>
            <thead>
              <tr><th>ID</th><th>Title</th><th>Level</th><th>Target Role</th><th>Duration</th><th>Enrollments</th><th>Completion %</th></tr>
            </thead>
            <tbody>
              {paths.map(p => (
                <tr key={p.Id}>
                  <td style={{color:'#888',fontWeight:600}}>#{p.Id}</td>
                  <td style={{fontWeight:500}}>{p.Title}</td>
                  <td><span className="kh-badge" style={{background:'#f3f2f1',color:'#323130'}}>{p.Level}</span></td>
                  <td>{p.TargetRole}</td>
                  <td>{p.DurationHours}h</td>
                  <td>{p.EnrollmentCount}</td>
                  <td>
                    <div style={{display:'flex',alignItems:'center',gap:'6px'}}>
                      <div style={{flex:1,height:'6px',background:'#e0e0e0',borderRadius:'3px',overflow:'hidden'}}>
                        <div style={{width:`${p.CompletionRate}%`,height:'100%',background:'#107c10',borderRadius:'3px'}}/>
                      </div>
                      <span style={{fontSize:'11px',color:'#888'}}>{p.CompletionRate}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selectedTab === 'users' && (
        <div className={styles.settingsPanel}>
          <h4 className={styles.settingsTitle}>⚙️ Configuration Guide</h4>
          <div className={styles.settingItem}>
            <span className={styles.settingLabel}>Admin Group</span>
            <span className={styles.settingValue}>Configure in Web Part Property Pane → Security Groups → Admin Group Name</span>
          </div>
          <div className={styles.settingItem}>
            <span className={styles.settingLabel}>Author Group</span>
            <span className={styles.settingValue}>Configure in Web Part Property Pane → Security Groups → Author Group Name</span>
          </div>
          <div className={styles.settingItem}>
            <span className={styles.settingLabel}>Power Automate</span>
            <span className={styles.settingValue}>Add your Flow HTTP trigger URL in Property Pane → Power Automate → Flow Webhook URL</span>
          </div>
          <div className={styles.settingItem}>
            <span className={styles.settingLabel}>Lists Required</span>
            <span className={styles.settingValue}>KH_Articles, KH_Categories, KH_Ratings, KH_LearningPaths, KH_Enrollments</span>
          </div>
          <div className={styles.settingItem}>
            <span className={styles.settingLabel}>Graph Permissions</span>
            <span className={styles.settingValue}>User.Read, User.ReadBasic.All, People.Read — approve in SharePoint Admin Center → API Access</span>
          </div>
        </div>
      )}
    </div>
  );
};
export default AdminView;