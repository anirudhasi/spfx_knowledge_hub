import * as React from 'react';
import { IAnalyticsData } from '../interfaces/IModels';
import styles from './AnalyticsView.module.scss';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line
} from 'recharts';

interface IProps {
  analytics: IAnalyticsData | null;
  onExportArticles: () => void;
  onExportPaths: () => void;
}

const COLORS = ['#0078d4','#107c10','#7a4100','#a4262c','#5c2d91','#00b4d8','#ff6b35','#2e86ab'];

const KPICard: React.FunctionComponent<{icon:string;label:string;value:string|number;color:string;bg:string}> = ({icon,label,value,color,bg}) => (
  <div className={styles.kpiCard} style={{borderTop:`3px solid ${color}`,background:bg}}>
    <span className={styles.kpiIcon}>{icon}</span>
    <span className={styles.kpiValue} style={{color}}>{value}</span>
    <span className={styles.kpiLabel}>{label}</span>
  </div>
);

const AnalyticsView: React.FunctionComponent<IProps> = ({ analytics, onExportArticles, onExportPaths }) => {
  if (!analytics) return (
    <div className={styles.loading}><div className={styles.spinner} /><p>Loading analytics...</p></div>
  );
  return (
    <div className={styles.analyticsView}>
      <div className={styles.toolbar}>
        <h3 className={styles.viewTitle}>📊 Knowledge Hub Analytics</h3>
        <div className={styles.exportBtns}>
          <button className="kh-btn-secondary" onClick={onExportArticles}>📥 Export Articles</button>
          <button className="kh-btn-secondary" onClick={onExportPaths}>📥 Export Paths</button>
        </div>
      </div>

      {/* KPI Row */}
      <div className={styles.kpiRow}>
        <KPICard icon="📚" label="Total Articles" value={analytics.totalArticles} color="#0078d4" bg="#deecf9"/>
        <KPICard icon="👁" label="Total Views" value={analytics.totalViews.toLocaleString()} color="#107c10" bg="#dff6dd"/>
        <KPICard icon="🎓" label="Enrollments" value={analytics.totalEnrollments} color="#7a4100" bg="#fff4ce"/>
        <KPICard icon="⭐" label="Avg Rating" value={analytics.avgRating.toFixed(1)} color="#a4262c" bg="#fde7e9"/>
      </div>

      {/* Charts Row 1 */}
      <div className={styles.chartsRow}>
        <div className={styles.chartCard}>
          <h4 className={styles.chartTitle}>📁 Articles by Category</h4>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={analytics.categoryStats} margin={{top:5,right:10,bottom:20,left:0}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
              <XAxis dataKey="category" tick={{fontSize:11}} angle={-30} textAnchor="end" interval={0}/>
              <YAxis tick={{fontSize:11}}/>
              <Tooltip/>
              <Bar dataKey="articleCount" fill="#0078d4" radius={[4,4,0,0]} name="Articles"/>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className={styles.chartCard}>
          <h4 className={styles.chartTitle}>👁 Views by Category</h4>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={analytics.categoryStats} dataKey="totalViews" nameKey="category"
                cx="50%" cy="50%" outerRadius={80} label={({category,percent}) => `${category}: ${(percent*100).toFixed(0)}%`}
                labelLine={false}>
                {analytics.categoryStats.map((_,i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
              </Pie>
              <Tooltip/>
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className={styles.chartsRow}>
        <div className={styles.chartCard}>
          <h4 className={styles.chartTitle}>📈 Monthly Trend (Last 6 Months)</h4>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={analytics.monthlyStats} margin={{top:5,right:10,bottom:5,left:0}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
              <XAxis dataKey="month" tick={{fontSize:11}}/>
              <YAxis tick={{fontSize:11}}/>
              <Tooltip/>
              <Legend/>
              <Line type="monotone" dataKey="articlesCreated" stroke="#0078d4" strokeWidth={2} dot name="New Articles"/>
              <Line type="monotone" dataKey="newEnrollments" stroke="#107c10" strokeWidth={2} dot name="Enrollments"/>
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className={styles.chartCard}>
          <h4 className={styles.chartTitle}>⭐ Rating Distribution</h4>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={analytics.ratingDistribution} margin={{top:5,right:10,bottom:5,left:0}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
              <XAxis dataKey="rating" tick={{fontSize:11}}/>
              <YAxis tick={{fontSize:11}}/>
              <Tooltip/>
              <Bar dataKey="count" fill="#f59e0b" radius={[4,4,0,0]} name="Reviews"/>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top Articles Table */}
      <div className={styles.topArticlesCard}>
        <h4 className={styles.chartTitle}>🏆 Top 5 Articles by Views</h4>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>#</th><th>Title</th><th>Category</th><th>Author</th>
              <th>Views</th><th>Rating</th><th>Read Time</th>
            </tr>
          </thead>
          <tbody>
            {analytics.topArticles.map((a, i) => (
              <tr key={a.Id}>
                <td className={styles.rankCell}>#{i+1}</td>
                <td className={styles.titleCell}>{a.Title}</td>
                <td><span className="kh-badge" style={{background:'#f3f2f1',color:'#323130'}}>{a.Category}</span></td>
                <td>{a.AuthorName}</td>
                <td><strong>{a.ViewCount}</strong></td>
                <td>
                  <span className={styles.tableStars}>
                    {[1,2,3,4,5].map(s=><span key={s} className={s<=Math.round(a.AverageRating||0)?'kh-star-filled':'kh-star-empty'} style={{fontSize:'12px'}}>★</span>)}
                    <span style={{fontSize:'11px',color:'#888',marginLeft:'3px'}}>{(a.AverageRating||0).toFixed(1)}</span>
                  </span>
                </td>
                <td>{a.EstimatedReadMin}m</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
export default AnalyticsView;