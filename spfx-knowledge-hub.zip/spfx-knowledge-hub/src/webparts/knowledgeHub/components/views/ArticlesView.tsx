import * as React from 'react';
import { IArticle, ICategory, TRole } from '../interfaces/IModels';
import styles from './ArticlesView.module.scss';

interface IArticlesViewProps {
  articles: IArticle[];
  categories: ICategory[];
  userRole: TRole;
  searchQuery: string;
  selectedCategory: string;
  selectedStatus: string;
  sortBy: string;
  onOpenArticle: (id: number) => void;
  onFilterChange: (search: string, category: string, status: string, sort: string) => void;
  onExport: () => void;
}

const ArticlesView: React.FunctionComponent<IArticlesViewProps> = (props) => {
  const { articles, categories, userRole, searchQuery, selectedCategory, selectedStatus, sortBy,
    onOpenArticle, onFilterChange, onExport } = props;

  const [localSearch, setLocalSearch] = React.useState(searchQuery);

  const handleSearch = (val: string): void => {
    setLocalSearch(val);
    onFilterChange(val, selectedCategory, selectedStatus, sortBy);
  };

  const tagColors: Record<string,{bg:string,color:string}> = {
    'Published': {bg:'#dff6dd',color:'#107c10'},
    'Draft':     {bg:'#fff4ce',color:'#7a4100'},
    'Archived':  {bg:'#f3f2f1',color:'#605e5c'},
    'UnderReview':{bg:'#deecf9',color:'#0078d4'},
  };

  const priorityDot: Record<string,string> = { High:'#a4262c', Medium:'#7a4100', Low:'#107c10' };

  return (
    <div className={styles.articlesView}>
      {/* Toolbar */}
      <div className={styles.toolbar}>
        <div className={styles.searchBox}>
          <span className={styles.searchIcon}>🔍</span>
          <input
            className={`kh-input ${styles.searchInput}`}
            placeholder="Search articles, authors, tags..."
            value={localSearch}
            onChange={e => handleSearch(e.target.value)}
          />
          {localSearch && (
            <button className={styles.clearSearch} onClick={() => handleSearch('')}>✕</button>
          )}
        </div>
        <div className={styles.filters}>
          <select className="kh-select" value={selectedCategory}
            onChange={e => onFilterChange(localSearch, e.target.value, selectedStatus, sortBy)}>
            <option value="All">All Categories</option>
            {categories.map(c => <option key={c.Id} value={c.Title}>{c.Icon} {c.Title}</option>)}
          </select>
          {(userRole === 'Author' || userRole === 'Admin') && (
            <select className="kh-select" value={selectedStatus}
              onChange={e => onFilterChange(localSearch, selectedCategory, e.target.value, sortBy)}>
              <option value="All">All Status</option>
              <option value="Published">Published</option>
              <option value="Draft">Draft</option>
              <option value="UnderReview">Under Review</option>
              <option value="Archived">Archived</option>
            </select>
          )}
          <select className="kh-select" value={sortBy}
            onChange={e => onFilterChange(localSearch, selectedCategory, selectedStatus, e.target.value)}>
            <option value="newest">Newest First</option>
            <option value="popular">Most Views</option>
            <option value="rating">Top Rated</option>
          </select>
          <button className="kh-btn-secondary" onClick={onExport} title="Export to CSV">
            📥 Export
          </button>
        </div>
      </div>

      <div className={styles.resultsInfo}>
        Showing <strong>{articles.length}</strong> article{articles.length !== 1 ? 's' : ''}
        {localSearch && ` for "${localSearch}"`}
      </div>

      {articles.length === 0 ? (
        <div className="kh-empty">
          <span className="kh-empty-icon">📭</span>
          <p>No articles found. Try adjusting your filters.</p>
        </div>
      ) : (
        <div className={styles.grid}>
          {articles.map(a => {
            const sc = tagColors[a.Status] || tagColors['Draft'];
            return (
              <div key={a.Id} className="kh-card" onClick={() => onOpenArticle(a.Id)}>
                <div className={styles.cardTop}>
                  <span className="kh-badge" style={{background:sc.bg,color:sc.color}}>{a.Status}</span>
                  <span className="kh-badge" style={{background:'#f3f2f1',color:'#323130'}}>{a.Category}</span>
                </div>
                <h3 className={styles.title}>{a.Title}</h3>
                <p className={styles.summary}>
                  {a.Summary.length > 110 ? a.Summary.substring(0,110)+'...' : a.Summary}
                </p>
                {a.Tags && (
                  <div className={styles.tags}>
                    {a.Tags.split(',').slice(0,3).map((t,i) => (
                      <span key={i} className={styles.tag}>{t.trim()}</span>
                    ))}
                  </div>
                )}
                <div className={styles.cardMeta}>
                  <span>👤 {a.AuthorName}</span>
                  <span>⏱ {a.EstimatedReadMin}m</span>
                  <span>👁 {a.ViewCount}</span>
                </div>
                <div className={styles.cardBottom}>
                  <div className={styles.stars}>
                    {[1,2,3,4,5].map(s => (
                      <span key={s} className={s <= Math.round(a.AverageRating||0) ? 'kh-star-filled' : 'kh-star-empty'}>★</span>
                    ))}
                    <span style={{fontSize:'11px',color:'#888',marginLeft:'3px'}}>({a.RatingCount||0})</span>
                  </div>
                  <span style={{fontSize:'11px',color:'#888'}}>{new Date(a.Created).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'})}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
export default ArticlesView;