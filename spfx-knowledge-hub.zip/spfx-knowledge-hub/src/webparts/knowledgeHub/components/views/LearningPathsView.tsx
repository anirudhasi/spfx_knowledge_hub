import * as React from 'react';
import { ILearningPath, IEnrollment, IArticle, TRole } from '../interfaces/IModels';
import styles from './LearningPathsView.module.scss';

interface IProps {
  paths: ILearningPath[];
  enrollments: IEnrollment[];
  articles: IArticle[];
  currentUserId: string;
  userRole: TRole;
  onEnroll: (id: number, title: string) => void;
  onUpdateProgress: (enrollId: number, progress: number) => void;
  onExport: () => void;
}

const LEVEL_COLORS: Record<string,{bg:string,color:string}> = {
  'Beginner':     {bg:'#dff6dd',color:'#107c10'},
  'Intermediate': {bg:'#fff4ce',color:'#7a4100'},
  'Advanced':     {bg:'#fde7e9',color:'#a4262c'},
};

const LearningPathsView: React.FunctionComponent<IProps> = (props) => {
  const { paths, enrollments, articles, currentUserId, onEnroll, onUpdateProgress, onExport } = props;
  const [selectedLevel, setSelectedLevel] = React.useState('All');

  const myEnrollments = enrollments;
  const getEnrollment = (pathId: number): IEnrollment | undefined =>
    myEnrollments.find(e => e.LearningPathId === pathId);

  const filtered = selectedLevel === 'All' ? paths : paths.filter(p => p.Level === selectedLevel);

  return (
    <div className={styles.lpView}>
      <div className={styles.toolbar}>
        <h3 className={styles.viewTitle}>🎓 Learning Paths</h3>
        <div className={styles.controls}>
          <select className="kh-select" value={selectedLevel} onChange={e => setSelectedLevel(e.target.value)}>
            <option value="All">All Levels</option>
            <option value="Beginner">🟢 Beginner</option>
            <option value="Intermediate">🟡 Intermediate</option>
            <option value="Advanced">🔴 Advanced</option>
          </select>
          <button className="kh-btn-secondary" onClick={onExport}>📥 Export Enrollments</button>
        </div>
      </div>

      {/* My Progress */}
      {myEnrollments.length > 0 && (
        <div className={styles.myProgress}>
          <h4 className={styles.subTitle}>📋 My Enrolled Paths</h4>
          <div className={styles.enrolledList}>
            {myEnrollments.map(e => (
              <div key={e.Id} className={styles.enrolledItem}>
                <div className={styles.enrolledInfo}>
                  <span className={styles.enrolledTitle}>{e.LearningPathTitle}</span>
                  <span className={styles.enrolledStatus}>{e.Status}</span>
                </div>
                <div className={styles.progressWrapper}>
                  <div className={styles.progressBar}>
                    <div className={styles.progressFill} style={{width:`${e.Progress}%`, background: e.Progress >= 100 ? '#107c10' : '#0078d4'}} />
                  </div>
                  <span className={styles.progressLabel}>{e.Progress}%</span>
                </div>
                {e.Progress < 100 && (
                  <button className="kh-btn-secondary" style={{fontSize:'12px',padding:'5px 12px'}}
                    onClick={() => onUpdateProgress(e.Id, Math.min(100, e.Progress + 25))}>
                    +25%
                  </button>
                )}
                {e.Progress >= 100 && <span style={{color:'#107c10',fontWeight:600,fontSize:'13px'}}>✅ Complete</span>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Paths Grid */}
      <div className={styles.pathsGrid}>
        {filtered.map(p => {
          const enrollment = getEnrollment(p.Id);
          const lc = LEVEL_COLORS[p.Level] || LEVEL_COLORS['Beginner'];
          const articleCount = p.ArticleIds ? JSON.parse(p.ArticleIds).length : 0;
          return (
            <div key={p.Id} className={styles.pathCard}>
              <div className={styles.pathCardHeader}>
                <span className="kh-badge" style={{background:lc.bg,color:lc.color}}>{p.Level}</span>
                <span className={styles.pathDuration}>⏱ {p.DurationHours}h</span>
              </div>
              <h3 className={styles.pathTitle}>{p.Title}</h3>
              <p className={styles.pathDesc}>{p.Description.length > 120 ? p.Description.substring(0,120)+'...' : p.Description}</p>
              <div className={styles.pathMeta}>
                <span>👥 {p.TargetRole}</span>
                <span>📚 {articleCount} articles</span>
                <span>🎓 {p.EnrollmentCount} enrolled</span>
              </div>
              {enrollment ? (
                <div className={styles.enrolledTag}>
                  <div className={styles.progressBar} style={{marginBottom:'6px'}}>
                    <div className={styles.progressFill} style={{width:`${enrollment.Progress}%`,background:enrollment.Progress>=100?'#107c10':'#0078d4'}} />
                  </div>
                  <span style={{fontSize:'12px',color:'#605e5c'}}>Progress: {enrollment.Progress}% · {enrollment.Status}</span>
                </div>
              ) : (
                <button className="kh-btn-primary" style={{width:'100%',marginTop:'12px'}}
                  onClick={() => onEnroll(p.Id, p.Title)}>
                  🎓 Enroll Now
                </button>
              )}
            </div>
          );
        })}
      </div>
      {filtered.length === 0 && (
        <div className="kh-empty"><span className="kh-empty-icon">🎓</span><p>No learning paths found for this level.</p></div>
      )}
    </div>
  );
};
export default LearningPathsView;