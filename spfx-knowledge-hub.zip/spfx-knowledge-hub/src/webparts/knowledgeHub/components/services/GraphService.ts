import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IUserProfile } from '../interfaces/IModels';

export class GraphService {
  private _context: WebPartContext;

  constructor(context: WebPartContext) {
    this._context = context;
  }

  public async getCurrentUserProfile(): Promise<IUserProfile> {
    try {
      const client = await this._context.msGraphClientFactory.getClient('3');

      // Get user details
      const user = await client
        .api('/me')
        .select('id,displayName,mail,jobTitle,department,officeLocation,mobilePhone')
        .get();

      // Get user photo as base64
      let photoUrl = '';
      try {
        const photoResponse = await client.api('/me/photo/$value').responseType('blob' as any).get();
        photoUrl = await this._blobToBase64(photoResponse);
      } catch {
        photoUrl = ''; // no photo set
      }

      // Get manager
      let managerName = '';
      let managerEmail = '';
      try {
        const mgr = await client.api('/me/manager').select('displayName,mail').get();
        managerName = mgr.displayName || '';
        managerEmail = mgr.mail || '';
      } catch {
        // no manager
      }

      return {
        id: user.id || '',
        displayName: user.displayName || '',
        email: user.mail || '',
        jobTitle: user.jobTitle || '',
        department: user.department || '',
        officeLocation: user.officeLocation || '',
        mobilePhone: user.mobilePhone || '',
        photo: photoUrl,
        managerName,
        managerEmail,
      };
    } catch (err) {
      console.error('[KH] GraphService.getCurrentUserProfile error:', err);
      return {
        id: '',
        displayName: this._context.pageContext.user.displayName,
        email: this._context.pageContext.user.email,
        jobTitle: '',
        department: '',
        officeLocation: '',
        mobilePhone: '',
        photo: '',
        managerName: '',
        managerEmail: '',
      };
    }
  }

  public async getUserByEmail(email: string): Promise<Partial<IUserProfile>> {
    try {
      const client = await this._context.msGraphClientFactory.getClient('3');
      const user = await client
        .api(`/users/${email}`)
        .select('id,displayName,mail,jobTitle,department')
        .get();
      return {
        id: user.id,
        displayName: user.displayName,
        email: user.mail,
        jobTitle: user.jobTitle,
        department: user.department,
      };
    } catch {
      return { displayName: email };
    }
  }

  public async searchUsers(query: string): Promise<Partial<IUserProfile>[]> {
    try {
      const client = await this._context.msGraphClientFactory.getClient('3');
      const result = await client
        .api('/users')
        .filter(`startsWith(displayName,'${query}') or startsWith(mail,'${query}')`)
        .select('id,displayName,mail,jobTitle,department')
        .top(10)
        .get();
      return (result.value || []).map((u: any) => ({
        id: u.id, displayName: u.displayName,
        email: u.mail, jobTitle: u.jobTitle, department: u.department,
      }));
    } catch {
      return [];
    }
  }

  private _blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }
}
