import { IArticle, ILearningPath, IEnrollment } from '../interfaces/IModels';

export class ExcelExportService {

  public static exportArticles(articles: IArticle[], filename = 'KH_Articles_Export'): void {
    const headers = ['ID','Title','Category','Status','Author','Tags','Views','Avg Rating','Read Time (min)','Created'];
    const rows = articles.map(a => [
      a.Id, a.Title, a.Category, a.Status,
      a.AuthorName, a.Tags, a.ViewCount,
      a.AverageRating?.toFixed(1) || '0.0',
      a.EstimatedReadMin,
      new Date(a.Created).toLocaleDateString('en-GB'),
    ]);
    this._downloadCSV([headers, ...rows], filename);
  }

  public static exportEnrollments(enrollments: IEnrollment[], filename = 'KH_Enrollments_Export'): void {
    const headers = ['ID','User','Email','Learning Path','Progress (%)','Status','Enrolled Date','Completed Date'];
    const rows = enrollments.map(e => [
      e.Id, e.UserName, e.UserEmail, e.LearningPathTitle,
      e.Progress, e.Status,
      e.EnrolledDate ? new Date(e.EnrolledDate).toLocaleDateString('en-GB') : '',
      e.CompletedDate ? new Date(e.CompletedDate).toLocaleDateString('en-GB') : '',
    ]);
    this._downloadCSV([headers, ...rows], filename);
  }

  public static exportLearningPaths(paths: ILearningPath[], filename = 'KH_LearningPaths_Export'): void {
    const headers = ['ID','Title','Level','Target Role','Duration (hrs)','Enrollments','Completion Rate (%)'];
    const rows = paths.map(p => [
      p.Id, p.Title, p.Level, p.TargetRole,
      p.DurationHours, p.EnrollmentCount, p.CompletionRate,
    ]);
    this._downloadCSV([headers, ...rows], filename);
  }

  private static _downloadCSV(data: (string | number)[][], filename: string): void {
    const csv = data.map(row =>
      row.map(cell => {
        const s = String(cell ?? '');
        return s.includes(',') || s.includes('"') || s.includes('\n')
          ? `"${s.replace(/"/g, '""')}"` : s;
      }).join(',')
    ).join('\r\n');

    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
