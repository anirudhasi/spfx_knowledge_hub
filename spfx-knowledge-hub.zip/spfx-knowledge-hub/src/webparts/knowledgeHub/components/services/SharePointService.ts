import { SPFI } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/site-users';
import {
  IArticle, INewArticle, ICategory, IRating, INewRating,
  ILearningPath, IEnrollment, IAnalyticsData, ICategoryStats,
  IMonthlyStats, TRole
} from '../interfaces/IModels';

export class SharePointService {
  private _sp: SPFI;

  public static readonly LISTS = {
    ARTICLES:    'KH_Articles',
    CATEGORIES:  'KH_Categories',
    RATINGS:     'KH_Ratings',
    PATHS:       'KH_LearningPaths',
    ENROLLMENTS: 'KH_Enrollments',
  };

  constructor(sp: SPFI) { this._sp = sp; }

  // ─── ARTICLES ─────────────────────────────────────────────────────────────

  public async getArticles(onlyPublished = false): Promise<IArticle[]> {
    const raw = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.ARTICLES).items
      .select('Id','Title','Summary','Content','Category','Tags',
        'AuthorEmail','AuthorName','Status','ViewCount',
        'FeaturedImage','IsFeatured','EstimatedReadMin','Created','Modified')
      .orderBy('Created', false).top(500)();

    let articles: IArticle[] = raw.map((i: any) => ({
      Id: i.Id, Title: i.Title || '', Summary: i.Summary || '',
      Content: i.Content || '', Category: i.Category || 'General',
      Tags: i.Tags || '', AuthorEmail: i.AuthorEmail || '',
      AuthorName: i.AuthorName || '', Status: i.Status || 'Draft',
      ViewCount: i.ViewCount || 0, FeaturedImage: i.FeaturedImage || '',
      IsFeatured: !!i.IsFeatured, EstimatedReadMin: i.EstimatedReadMin || 5,
      Created: i.Created || '', Modified: i.Modified || '',
      AverageRating: 0, RatingCount: 0,
    }));

    if (onlyPublished) articles = articles.filter(a => a.Status === 'Published');

    const allRatings = await this.getAllRatings();
    articles.forEach(a => {
      const r = allRatings.filter(x => x.ArticleId === a.Id);
      a.RatingCount = r.length;
      a.AverageRating = r.length ? Math.round((r.reduce((s, x) => s + x.Rating, 0) / r.length) * 10) / 10 : 0;
    });
    return articles;
  }

  public async getArticleById(id: number): Promise<IArticle> {
    const i = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.ARTICLES).items.getById(id)
      .select('Id','Title','Summary','Content','Category','Tags',
        'AuthorEmail','AuthorName','Status','ViewCount',
        'FeaturedImage','IsFeatured','EstimatedReadMin','Created','Modified')();
    return {
      Id: i.Id, Title: i.Title, Summary: i.Summary || '',
      Content: i.Content || '', Category: i.Category || '',
      Tags: i.Tags || '', AuthorEmail: i.AuthorEmail || '',
      AuthorName: i.AuthorName || '', Status: i.Status,
      ViewCount: i.ViewCount || 0, FeaturedImage: i.FeaturedImage || '',
      IsFeatured: !!i.IsFeatured, EstimatedReadMin: i.EstimatedReadMin || 5,
      Created: i.Created, Modified: i.Modified,
    };
  }

  public async createArticle(data: INewArticle, authorName: string, authorEmail: string): Promise<number> {
    const result = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.ARTICLES).items.add({
        Title: data.Title, Summary: data.Summary, Content: data.Content,
        Category: data.Category, Tags: data.Tags,
        AuthorEmail: authorEmail, AuthorName: authorName,
        Status: data.Status, ViewCount: 0,
        FeaturedImage: data.FeaturedImage || '',
        IsFeatured: data.IsFeatured || false,
        EstimatedReadMin: data.EstimatedReadMin || 5,
      });
    return result.Id;
  }

  public async updateArticle(id: number, data: Partial<INewArticle>): Promise<void> {
    await this._sp.web.lists.getByTitle(SharePointService.LISTS.ARTICLES)
      .items.getById(id).update(data);
  }

  public async deleteArticle(id: number): Promise<void> {
    await this._sp.web.lists.getByTitle(SharePointService.LISTS.ARTICLES)
      .items.getById(id).delete();
  }

  public async incrementViewCount(id: number, current: number): Promise<void> {
    await this._sp.web.lists.getByTitle(SharePointService.LISTS.ARTICLES)
      .items.getById(id).update({ ViewCount: current + 1 });
  }

  // ─── CATEGORIES ───────────────────────────────────────────────────────────

  public async getCategories(): Promise<ICategory[]> {
    const raw = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.CATEGORIES).items
      .select('Id','Title','Description','Icon','ParentCategory')
      .orderBy('Title', true)();
    return raw.map((i: any) => ({
      Id: i.Id, Title: i.Title, Description: i.Description || '',
      Icon: i.Icon || '📁', ParentCategory: i.ParentCategory || '',
    }));
  }

  // ─── RATINGS ──────────────────────────────────────────────────────────────

  public async getAllRatings(): Promise<IRating[]> {
    const raw = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.RATINGS).items
      .select('Id','ArticleId','UserId','UserName','Rating','Comment','HelpfulVotes','Created')
      .top(2000)();
    return raw.map((i: any) => ({
      Id: i.Id, ArticleId: i.ArticleId, UserId: i.UserId || '',
      UserName: i.UserName || '', Rating: i.Rating || 0,
      Comment: i.Comment || '', HelpfulVotes: i.HelpfulVotes || 0,
      Created: i.Created,
    }));
  }

  public async getRatingsByArticle(articleId: number): Promise<IRating[]> {
    const raw = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.RATINGS).items
      .filter(`ArticleId eq ${articleId}`)
      .select('Id','ArticleId','UserId','UserName','Rating','Comment','HelpfulVotes','Created')
      .orderBy('Created', false)();
    return raw.map((i: any) => ({
      Id: i.Id, ArticleId: i.ArticleId, UserId: i.UserId || '',
      UserName: i.UserName || '', Rating: i.Rating || 0,
      Comment: i.Comment || '', HelpfulVotes: i.HelpfulVotes || 0,
      Created: i.Created,
    }));
  }

  public async submitRating(data: INewRating): Promise<void> {
    const existing = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.RATINGS).items
      .filter(`ArticleId eq ${data.ArticleId} and UserId eq '${data.UserId}'`).top(1)();
    if (existing.length > 0) {
      await this._sp.web.lists.getByTitle(SharePointService.LISTS.RATINGS)
        .items.getById(existing[0].Id).update({ Rating: data.Rating, Comment: data.Comment });
    } else {
      await this._sp.web.lists.getByTitle(SharePointService.LISTS.RATINGS).items.add({
        ArticleId: data.ArticleId, UserId: data.UserId,
        UserName: data.UserName, Rating: data.Rating,
        Comment: data.Comment, HelpfulVotes: 0,
      });
    }
  }

  // ─── LEARNING PATHS ───────────────────────────────────────────────────────

  public async getLearningPaths(): Promise<ILearningPath[]> {
    const raw = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.PATHS).items
      .select('Id','Title','Description','ArticleIds','TargetRole','Level',
        'DurationHours','EnrollmentCount','CompletionRate','ThumbnailUrl','IsActive','Created')
      .filter('IsActive eq 1').orderBy('Title', true)();
    return raw.map((i: any) => ({
      Id: i.Id, Title: i.Title, Description: i.Description || '',
      ArticleIds: i.ArticleIds || '[]', TargetRole: i.TargetRole || 'All',
      Level: i.Level || 'Beginner', DurationHours: i.DurationHours || 1,
      EnrollmentCount: i.EnrollmentCount || 0, CompletionRate: i.CompletionRate || 0,
      ThumbnailUrl: i.ThumbnailUrl || '', IsActive: !!i.IsActive, Created: i.Created,
    }));
  }

  // ─── ENROLLMENTS ──────────────────────────────────────────────────────────

  public async getEnrollmentsByUser(userId: string): Promise<IEnrollment[]> {
    const raw = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.ENROLLMENTS).items
      .filter(`UserId eq '${userId}'`)
      .select('Id','UserId','UserName','UserEmail','LearningPathId','LearningPathTitle',
        'Progress','Status','EnrolledDate','CompletedDate','LastAccessedDate')();
    return raw.map((i: any) => ({
      Id: i.Id, UserId: i.UserId, UserName: i.UserName || '',
      UserEmail: i.UserEmail || '', LearningPathId: i.LearningPathId,
      LearningPathTitle: i.LearningPathTitle || '', Progress: i.Progress || 0,
      Status: i.Status || 'Enrolled', EnrolledDate: i.EnrolledDate || '',
      CompletedDate: i.CompletedDate || '', LastAccessedDate: i.LastAccessedDate || '',
    }));
  }

  public async enrollInPath(
    userId: string, userName: string, userEmail: string,
    pathId: number, pathTitle: string
  ): Promise<void> {
    const existing = await this._sp.web.lists
      .getByTitle(SharePointService.LISTS.ENROLLMENTS).items
      .filter(`UserId eq '${userId}' and LearningPathId eq ${pathId}`).top(1)();
    if (existing.length > 0) return;
    await this._sp.web.lists.getByTitle(SharePointService.LISTS.ENROLLMENTS).items.add({
      UserId: userId, UserName: userName, UserEmail: userEmail,
      LearningPathId: pathId, LearningPathTitle: pathTitle,
      Progress: 0, Status: 'Enrolled',
      EnrolledDate: new Date().toISOString(),
      LastAccessedDate: new Date().toISOString(),
    });
    const path = await this._sp.web.lists.getByTitle(SharePointService.LISTS.PATHS)
      .items.getById(pathId).select('EnrollmentCount')();
    await this._sp.web.lists.getByTitle(SharePointService.LISTS.PATHS)
      .items.getById(pathId).update({ EnrollmentCount: (path.EnrollmentCount || 0) + 1 });
  }

  public async updateProgress(enrollmentId: number, progress: number): Promise<void> {
    const status = progress >= 100 ? 'Completed' : progress > 0 ? 'InProgress' : 'Enrolled';
    await this._sp.web.lists.getByTitle(SharePointService.LISTS.ENROLLMENTS)
      .items.getById(enrollmentId).update({
        Progress: progress, Status: status,
        LastAccessedDate: new Date().toISOString(),
        ...(progress >= 100 ? { CompletedDate: new Date().toISOString() } : {}),
      });
  }

  // ─── ROLE ─────────────────────────────────────────────────────────────────

  public async getUserRole(adminGroup: string, authorGroup: string): Promise<TRole> {
    try {
      const groups = await this._sp.web.currentUser.groups();
      const names = groups.map((g: any) => g.Title);
      if (names.includes(adminGroup)) return 'Admin';
      if (names.includes(authorGroup)) return 'Author';
      return 'Employee';
    } catch { return 'Employee'; }
  }

  // ─── ANALYTICS ────────────────────────────────────────────────────────────

  public async buildAnalytics(articles: IArticle[], enrollments: IEnrollment[]): Promise<IAnalyticsData> {
    const allRatings = await this.getAllRatings();
    const catMap: Record<string, ICategoryStats> = {};
    articles.forEach(a => {
      if (!catMap[a.Category]) catMap[a.Category] = { category: a.Category, articleCount: 0, totalViews: 0, avgRating: 0 };
      catMap[a.Category].articleCount++;
      catMap[a.Category].totalViews += a.ViewCount;
    });
    const monthly: Record<string, IMonthlyStats> = {};
    const now = new Date();
    for (let m = 5; m >= 0; m--) {
      const d = new Date(now.getFullYear(), now.getMonth() - m, 1);
      const key = d.toLocaleDateString('en-GB', { month: 'short', year: 'numeric' });
      monthly[key] = { month: key, articlesCreated: 0, totalViews: 0, newEnrollments: 0 };
    }
    articles.forEach(a => {
      const key = new Date(a.Created).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' });
      if (monthly[key]) { monthly[key].articlesCreated++; monthly[key].totalViews += a.ViewCount; }
    });
    enrollments.forEach(e => {
      const key = new Date(e.EnrolledDate).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' });
      if (monthly[key]) monthly[key].newEnrollments++;
    });
    const ratingDist = [1,2,3,4,5].map(r => ({
      rating: `${r}★`,
      count: allRatings.filter(rt => Math.round(rt.Rating) === r).length,
    }));
    return {
      categoryStats: Object.values(catMap),
      monthlyStats: Object.values(monthly),
      ratingDistribution: ratingDist,
      topArticles: [...articles].filter(a => a.Status === 'Published').sort((a,b) => b.ViewCount - a.ViewCount).slice(0,5),
      totalArticles: articles.length,
      totalViews: articles.reduce((s, a) => s + a.ViewCount, 0),
      totalEnrollments: enrollments.length,
      avgRating: allRatings.length ? Math.round((allRatings.reduce((s,r) => s + r.Rating, 0) / allRatings.length) * 10) / 10 : 0,
    };
  }

  // ─── POWER AUTOMATE ───────────────────────────────────────────────────────

  public async triggerFlow(webhookUrl: string, payload: Record<string, unknown>): Promise<void> {
    if (!webhookUrl) return;
    try {
      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    } catch (e) { console.warn('[KH] Flow trigger failed:', e); }
  }
}
