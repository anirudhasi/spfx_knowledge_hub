# Capgemini Knowledge Hub & Learning Portal
## SPFx Complex Project - Node 22 + HEFT | Capgemini Technology Services

---

## Overview
A **production-grade SharePoint Framework (SPFx) web part** that implements a full-featured corporate knowledge management and learning portal.

**Key capabilities:**
- 📚 Article library with search, filter, and sort
- ⭐ 5-star rating & review system  
- 🎓 Learning paths with enrollment and progress tracking
- 📊 Analytics dashboards (bar, line, pie charts via Recharts)
- 👤 Microsoft Graph API user profiles with photo
- 🔐 Role-based views (Employee / Author / Admin)
- 🧙 3-step article submission wizard
- ⚡ Power Automate flow trigger on article submit
- 📥 CSV export for articles, paths, enrollments
- ⚙️ Admin panel for content management

---

## Technology Stack

| Technology | Version | Purpose |
|-----------|---------|---------|
| SPFx | 1.20.0 | Web part framework |
| Node.js | 22.x LTS | Build runtime |
| HEFT | 0.66.0 | Modern build system |
| React | 17.0.1 | UI framework |
| TypeScript | 5.x | Type safety |
| PnPJS | 4.1.0 | SP REST API |
| Microsoft Graph | v3 client | User profiles, photos |
| Recharts | 2.10.3 | Charts & analytics |
| SCSS Modules | - | Scoped styles |

---

## Prerequisites

1. **Node.js 22 LTS** — https://nodejs.org
2. **SPFx toolchain:**
   ```bash
   npm install -g yo @microsoft/generator-sharepoint
   ```
3. **PnP PowerShell** (for list setup):
   ```powershell
   Install-Module PnP.PowerShell -Force
   ```
4. **Trust dev certificate:**
   ```bash
   gulp trust-dev-cert
   ```

---

## Quick Start

### Step 1: Install
```bash
cd spfx-knowledge-hub
npm install
```

### Step 2: Create SharePoint Lists
```powershell
cd setup
.\CreateKHLists.ps1 -SiteUrl "https://capgemini.sharepoint.com/sites/InventKnowledgeHub"
```

### Step 3: Approve Graph Permissions
1. Go to SharePoint Admin Center → Advanced → API access
2. Approve: User.Read, User.ReadBasic.All, People.Read, Directory.Read.All

### Step 4: Serve Locally
```bash
gulp serve
# OR with HEFT
heft start
```

### Step 5: Deploy
```bash
gulp bundle --ship
gulp package-solution --ship
# Upload sharepoint/solution/knowledge-hub.sppkg to App Catalog
```

---

## Project Structure

```
spfx-knowledge-hub/
├── .heft/
│   └── heft.json                    ← HEFT build config
├── config/
│   ├── config.json                  ← Bundle config
│   ├── package-solution.json        ← Graph API permissions
│   └── serve.json                   ← Dev server
├── src/webparts/knowledgeHub/
│   ├── KnowledgeHubWebPart.ts       ← Entry point + Property Pane
│   ├── KnowledgeHubWebPart.manifest.json
│   └── components/
│       ├── KnowledgeHub.tsx         ← Root component + state
│       ├── KnowledgeHub.module.scss ← Global shared styles
│       ├── interfaces/
│       │   ├── IModels.ts           ← All data models/interfaces
│       │   └── IKnowledgeHubProps.ts← Props + State interfaces
│       ├── services/
│       │   ├── SharePointService.ts ← 5-list CRUD + analytics
│       │   ├── GraphService.ts      ← Graph API user profiles
│       │   └── ExcelExportService.ts← CSV export utility
│       └── views/
│           ├── HomeView.tsx         ← Hero + categories + featured
│           ├── ArticlesView.tsx     ← Search + filter + article grid
│           ├── ArticleDetailView.tsx← Full article + rating/reviews
│           ├── LearningPathsView.tsx← Paths + enrollment + progress
│           ├── AnalyticsView.tsx    ← Charts dashboard
│           ├── AdminView.tsx        ← Admin content management
│           └── ArticleWizard.tsx    ← 3-step article submission
├── setup/
│   └── CreateKHLists.ps1           ← List provisioning script
├── data/                           ← Sample CSV files for import
└── package.json                    ← Node 22 + HEFT config
```

---

## SharePoint Lists

| List | Purpose |
|------|---------|
| KH_Articles | Article content store |
| KH_Categories | Article category taxonomy |
| KH_Ratings | User ratings & reviews |
| KH_LearningPaths | Learning path definitions |
| KH_Enrollments | User enrollment tracking |

---

## Role-Based Access

| Feature | Employee | Author | Admin |
|---------|----------|--------|-------|
| Browse & read articles | ✅ | ✅ | ✅ |
| Rate & review articles | ✅ | ✅ | ✅ |
| Enroll in learning paths | ✅ | ✅ | ✅ |
| Submit articles (wizard) | ❌ | ✅ | ✅ |
| Analytics dashboard | ❌ | ✅ | ✅ |
| Admin panel | ❌ | ❌ | ✅ |

---

## Author
**Capgemini Technology Services - Data Science & AI**  
Site: https://capgemini.sharepoint.com/sites/InventKnowledgeHub  
Contact: chirag.jain@capgemini.com